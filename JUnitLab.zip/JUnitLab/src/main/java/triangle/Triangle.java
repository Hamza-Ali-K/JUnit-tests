/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package triangle;
/**
 *
 * @author user
 */
public class Triangle {
    public TriangleType classify(int a, int b, int c) {
        // Invalid condition
        if (a <= 0 || b <= 0 || c <= 0) {
            return TriangleType.INVALID;
        }
        if (a + b <= c || a + c <= b || b + c <= a) {
            return TriangleType.INVALID;
        }
        // Equilateral
        if (a == b && b == c) {
            return TriangleType.EQUILATERAL;
        }
        // Isosceles
        if (a == b || b == c || a == c) {
            return TriangleType.ISOSCELES;
        }
        // Scalene
        return TriangleType.SCALENE;
    }
}
