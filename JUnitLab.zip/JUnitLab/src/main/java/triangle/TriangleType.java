/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package triangle;
/**
 *
 * @author user
 */
public enum TriangleType {
    EQUILATERAL,
    ISOSCELES,
    SCALENE,
    INVALID
}
