/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package numbers;
/**
 *
 * @author user
 */
public class EvenOdd {
    public boolean isEven(int num) {
        return num % 2 == 0;
    }
    public boolean isOdd(int num) {
        return num % 2 != 0;
    }
}
