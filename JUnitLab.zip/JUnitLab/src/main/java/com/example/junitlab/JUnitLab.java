/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.example.junitlab;

/**
 *
 * @author user
 */
public class JUnitLab {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
