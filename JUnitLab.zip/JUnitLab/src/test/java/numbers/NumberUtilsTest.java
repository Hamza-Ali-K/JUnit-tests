/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package numbers;
/**
 *
 * @author user
 */
import numbers.NumberUtils;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
public class NumberUtilsTest {
    NumberUtils num;
    @BeforeEach
    public void setup() {
        num = new NumberUtils();
    }
    @Test
    public void testPalindromeTrue() {
        Assertions.assertTrue(num.isPalindrome(121));
    }
    @Test
    public void testPalindromeFalse() {
        Assertions.assertFalse(num.isPalindrome(123));
    }
    @Test
    public void testFactorial() {
        Assertions.assertEquals(120, num.factorial(5));
    }
    @Test
    public void testSumOfDigits() {
        Assertions.assertEquals(6, num.sumOfDigits(123));
    }
}
