/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package numbers;
/**
 *
 * @author user
 */
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
public class EvenOddTest {
    EvenOdd eo = new EvenOdd();
    @Test
    void testEven() {
        assertTrue(eo.isEven(10));
    }
    @Test
    void testOdd() {
        assertTrue(eo.isOdd(7));
    }
}
