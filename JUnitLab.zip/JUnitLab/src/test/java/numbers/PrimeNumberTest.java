/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package numbers;
/**
 *
 * @author user
 */
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
public class PrimeNumberTest {
    PrimeNumber p = new PrimeNumber();
    @Test
    void testPrime() {
        assertTrue(p.isPrime(7));   // prime
    }
    @Test
    void testNotPrime() {
        assertFalse(p.isPrime(8)); // not prime
    }
}
