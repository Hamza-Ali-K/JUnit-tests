

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/**
 *
 * @author user
 */
import org.junit.platform.suite.api.SelectClasses;
import org.junit.platform.suite.api.Suite;
import numbers.PrimeNumberTest;
import numbers.EvenOddTest;
@Suite
@SelectClasses({
    PrimeNumberTest.class,
    EvenOddTest.class
})
public class AllTestSuite {
}