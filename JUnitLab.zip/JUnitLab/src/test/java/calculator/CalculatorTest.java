package calculator;
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/**
 *
 * @author user
 */
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
public class CalculatorTest {
    Calculator calc;
    @BeforeEach
    public void setup() {
        calc = new Calculator();
    }
   @Test
    public void testAddition() {
        Assertions.assertEquals(15, calc.add(10,5));
    }
    @Test
    public void testSubtraction() {
        Assertions.assertEquals(5, calc.subtract(10,5));
    }
    @Test
    public void testMultiplication() {
        Assertions.assertEquals(50, calc.multiply(10,5));
    }
    @Test
    public void testSquare() {
        Assertions.assertEquals(25, calc.square(5));
    }
    @Test
    public void testCube() {
        Assertions.assertEquals(27, calc.cube(3));
    }
}
