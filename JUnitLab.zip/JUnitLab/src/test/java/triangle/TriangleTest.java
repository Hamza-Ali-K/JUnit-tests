/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package triangle;
/**
 *
 * @author user
 */
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import triangle.Triangle;
import triangle.TriangleType;
public class TriangleTest {
    Triangle triangle;
    @BeforeEach
    public void setup() {
        triangle = new Triangle();
    }
    @Test
    public void testEquilateral() {
        Assertions.assertEquals(TriangleType.EQUILATERAL, triangle.classify(5,5,5));
    }
    @Test
    public void testIsosceles() {
        Assertions.assertEquals(TriangleType.ISOSCELES, triangle.classify(5,5,3));
    }
    @Test
    public void testScalene() {
        Assertions.assertEquals(TriangleType.SCALENE, triangle.classify(3,4,5));
    }
    @Test
    public void testInvalid() {
        Assertions.assertEquals(TriangleType.INVALID, triangle.classify(1,2,10));
    }
}
